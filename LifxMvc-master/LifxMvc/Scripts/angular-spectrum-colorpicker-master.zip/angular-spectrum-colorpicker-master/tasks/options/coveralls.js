module.exports = {
  coveralls: {
    src: '.tmp/coverage/lcov.info'
  }
};

module.exports = {
  watchdemo: {
    options: {
      grunt: true,
      stream: true
    },
    tasks: ['watch:partials', 'watch:demo']
  }
};

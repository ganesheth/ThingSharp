/* jshint unused: false, -W079 */
var angularSpectrumColorpicker = angular.module('angularSpectrumColorpicker', []);

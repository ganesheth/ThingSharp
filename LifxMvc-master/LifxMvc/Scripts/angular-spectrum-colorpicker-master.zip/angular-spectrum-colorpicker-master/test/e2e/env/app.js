angular.bootstrap(document, ['angularSpectrumColorpicker']);
